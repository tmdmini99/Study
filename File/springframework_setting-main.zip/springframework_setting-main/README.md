## 개발환경
- JDK: amazon corretto 11
- DB: mysql 
- mybatis
- view: JSP